var seaImage,shipIng
function preload(){
seaImage=loadImage("sea.png")
  shipImage = loadAnimation("ship1.png","ship2.png")
}

function setup(){
  createCanvas(400,400);
  sea=createSprite(400,200)
  sea.addImage("seaIng",seaImage)
  //code to reset the background
  sea.x = sea.width/8;
  
  //edges=createEdgeSprites();
   sea.velocityX=-5;
  sea.scale=0.3;
  // adding scale and position to shipIng
  ship = createSprite(130,200,30,30);
  ship.addAnimation("movingShip",shipImage);
  ship.scale =0.25;

  
}

function draw() {
 
   background("blue");
  //console.log(sea.x)
  if(sea.x < 0) {
  sea.x = sea.width/8;
  }
  
  //sea.velocityY=sea.velocityY + 0.5;
  
  //stop shipIng from falling down
  //ship.collide(sea)
  drawSprites();
}